# Groundater flow prediction using support vector machines : Bagoue region  dataset, North part of Cote d'Ivoire " 

 *** Cote d'Ivoire is french speaking country then most of data guidelines are written in French.***
 *** Data are collected during the Presidential Emmergency Program(PPU), National Program of Drinking Water Supply(PNAEP) and other geophysical locals firms.***
 

#Contributors
* Contributors of data collections 
	* Kouadio Kouao Laurent(1,2) 
	* Kouame Loukou Nicoloas (2)
	* Coulibaly Drissa (3)
	* Serge Pacome Deguine Gnoleba (2)
* Data processing
	* Kouadio Kouao Laurent (1,2)
	* Binbin Mi (1)
	* Zhang Hongzhu (1)
	* Serge Kouamelan Kouamelan (2,4)
	
**Overview 

These are are collected during 	PANEP project , PPU and other particular firms
the IP folder contains of preporcessing vertical electrical sounding of survey area set 
the ERT folder contain at the same time , the ERT data and the VES raw data 
The selected location for drilling are most likely highligthed or specified on ERT curve.

Coordinates are not the real coordinates of the area to keep the ` private contents of each survey locations`

Most of the sites are nammed by their code "b" + "index values".

**NOTE** : the main file used  to test codes after computed anomalies features [`numericals features` and `categorical features` ] 
is`____fmain.bagciv.data.csv` in locate `bagoue_test_data_2_case_history/`. 

Folder `__ves_preprocess_ip` contains the VES data inverted using IP2WIN and QLSEWN softwares.

## Contributors affilations 
  
1. Key Laboratory of Geoscience Big Data and Deep Resource of Zhejiang Province , School of Earth Sciences, Zhejiang University, China
2. Equipe de Recherche Géophysique Appliquée, Laboratoire de Géologie Ressources Minérales et Energétiques, UFR des Sciences de la Terre et des Ressources Minières, Université Félix Houphouët-Boigny, 22 BP 582 Abidjan 22 - Cote d'Ivoire
3. Laboratoire du Génie Civil, des Géosciences et des Sciences Géographiques, Ecole Supérieure des Mines et Géologie, Institut National Polytechnique d’Houphouët Boigny, BP 1093 Yamoussoukro- Côte d’Ivoire
4. Key Laboratory of Geo-Detection, School of Geophysics and Information Technology, China University of Geosciences, Beijing 100083, China

## Aknowlegnments 
The authors thank the Subsurface Imaging and Sensing Laboratory of School of *Earth Sciences of Zhejiang University and Laboratory of Geology Mineral Resources and Energy (LGRME)* of School of Earth Science and Mineral Resources (STRM)
 of Felix Houphouet Boigny University to lead the project. The authors gratefully acknowledge **IBRAHIM Berthe** of Cote d’Ivoire *National Office for Drinking Water (ONEP)* for his great involvement in the success of this project 
 for the rural population welfare. We also want to thank **BOFFOUE Moro Olivier** of Polytechnical University of Man (Cote d’Ivoire), **Soro Nanin** and **SOMBO Boko Celestin** of STRM, for their particular interest of the project by
 creating a monitoring framework of exchange since 2014. We specially thank **KONE Saramatou** of *Water Resources Department,* and **DIARASSOUBA Mada** of ONEP for their collaboration during geophysical data collection from other 
 companies. We are also grateful to DENIS Simonin of *FORACO-CI* for borehole data collection.